imgUrl1="data/afficheimg/20130822gmmodf.jpg";
imgtext1="";
imgLink1=escape("http://www.wjike.com/topic.php?topic_id=2");
imgUrl2="data/afficheimg/20121212yqejwy.jpg";
imgtext2="双立人 开普敦西餐具 ";
imgLink2=escape("../goods.php?id=708");
imgUrl3="data/afficheimg/20121212tjvaet.jpg";
imgtext3="";
imgLink3=escape("../goods.php?id=724");

var pics=imgUrl1+"|"+imgUrl2+"|"+imgUrl3;
var links=imgLink1+"|"+imgLink2+"|"+imgLink3;
var texts=imgtext1+"|"+imgtext2+"|"+imgtext3;