imgUrl1="data/afficheimg/20121127tqwuih.jpg";
imgtext1="测试首焦图尺寸";
imgLink1=escape("http://");

var pics=imgUrl1;
var links=imgLink1;
var texts=imgtext1;