<?php
// database host
// $db_host   = "192.168.0.102:3306";
//$db_host   = "210.51.14.229:3306";
$db_host = "localhost:3306";

// database name
$db_name   = "ecshop";//ECSHOP
//$db_name   = "ecshop";//ECSHOP

// database username
$db_user   = "admin";

// database password
$db_pass   = "admin123";//wjike123!

// table prefix
$prefix    = "ecs_";

$timezone    = "Asia/Shanghai";

$cookie_path    = "/";

$cookie_domain    = "";

$session = "1440";

define('EC_CHARSET','utf-8');

define('ADMIN_PATH','admin');

define('AUTH_KEY', 'this is a key');

define('OLD_AUTH_KEY', '');

define('API_TIME', '2014-06-18 09:05:06');

?>
